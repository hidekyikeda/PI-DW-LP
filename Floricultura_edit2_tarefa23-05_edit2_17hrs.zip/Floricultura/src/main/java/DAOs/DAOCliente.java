package DAOs;
import Entidades.Cliente;
import java.util.ArrayList;
import java.util.List;

public class DAOCliente extends DAOGenerico<Cliente> {

    public DAOCliente() {
        super(Cliente.class);
    }

    public int autoIdCliente() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idCliente) FROM Cliente e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Cliente> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.nome LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Cliente> listByCpf(String cpf) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.cpf = :cpf").setParameter("cpf", cpf).getResultList();
    }

    public List<Cliente> listInOrderNome() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.nome").getResultList();
    }

    public List<Cliente> listInOrderCpf() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.cpf").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Cliente> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderCpf();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getCpf()
 + "-" + lf.get(i).getNome()
 + "-" + lf.get(i).getLogin()
 + "-" + lf.get(i).getSenha()
 + "-" + lf.get(i).getEndereco()
);
        }
        return ls;
    }
}
