/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Hideky
 */
@Entity
@Table(name = "compra_has_flor")
@NamedQueries({
    @NamedQuery(name = "CompraHasFlor.findAll", query = "SELECT c FROM CompraHasFlor c")})
public class CompraHasFlor implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CompraHasFlorPK compraHasFlorPK;
    @Basic(optional = false)
    @Column(name = "qtd")
    private int qtd;
    @Basic(optional = false)
    @Column(name = "precoUnit")
    private float precoUnit;
    @JoinColumn(name = "compra_idcompra", referencedColumnName = "id_compra", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Compra compra;
    @JoinColumn(name = "flor_idflor", referencedColumnName = "id_flor", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Flor flor;

    public CompraHasFlor() {
    }

    public CompraHasFlor(CompraHasFlorPK compraHasFlorPK) {
        this.compraHasFlorPK = compraHasFlorPK;
    }

    public CompraHasFlor(CompraHasFlorPK compraHasFlorPK, int qtd, float precoUnit) {
        this.compraHasFlorPK = compraHasFlorPK;
        this.qtd = qtd;
        this.precoUnit = precoUnit;
    }

    public CompraHasFlor(int compraIdcompra, int florIdflor) {
        this.compraHasFlorPK = new CompraHasFlorPK(compraIdcompra, florIdflor);
    }

    public CompraHasFlorPK getCompraHasFlorPK() {
        return compraHasFlorPK;
    }

    public void setCompraHasFlorPK(CompraHasFlorPK compraHasFlorPK) {
        this.compraHasFlorPK = compraHasFlorPK;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public float getPrecoUnit() {
        return precoUnit;
    }

    public void setPrecoUnit(float precoUnit) {
        this.precoUnit = precoUnit;
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public Flor getFlor() {
        return flor;
    }

    public void setFlor(Flor flor) {
        this.flor = flor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (compraHasFlorPK != null ? compraHasFlorPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CompraHasFlor)) {
            return false;
        }
        CompraHasFlor other = (CompraHasFlor) object;
        if ((this.compraHasFlorPK == null && other.compraHasFlorPK != null) || (this.compraHasFlorPK != null && !this.compraHasFlorPK.equals(other.compraHasFlorPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.CompraHasFlor[ compraHasFlorPK=" + compraHasFlorPK + " ]";
    }
    
}
