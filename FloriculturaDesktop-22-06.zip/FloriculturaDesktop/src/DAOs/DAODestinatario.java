package DAOs;

import Entidades.Destinatario;
import java.util.ArrayList;
import java.util.List;

public class DAODestinatario extends DAOGenerico<Destinatario> {

    public DAODestinatario() {
        super(Destinatario.class);
    }

    public int autoIdDestinatario() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idDestinatario) FROM Destinatario e").getSingleResult();

        if (a != null) {

            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Destinatario> listById(int id) {
        return em.createQuery("SELECT e FROM Destinatario e WHERE e.idDestinatario = :id").setParameter("id", id).getResultList();
    }

    public List<Destinatario> listInOrderId() {
        return em.createQuery("SELECT e FROM Destinatario e ORDER BY e.idDestinatario").getResultList();
    }

    
    
    
    public List<Destinatario> listByEndereco(String endereco) {
        return em.createQuery("SELECT e FROM Destinatario e WHERE e.enderecoDestinatarioLIKE :endereco").setParameter("endereco", "%" + endereco + "%").getResultList();
    }

    public List<Destinatario> listInOrderEndereco() {
        return em.createQuery("SELECT e FROM Destinatario e ORDER BY e.enderecoDestinatario").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Destinatario> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderEndereco();
        }
        List<String> ls = new ArrayList<>();

        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdDestinatario() + "- (ID Destinatario)" + lf.get(i).getEndereco() + "- (Endereco)");
        }
            return ls;
        }
}
