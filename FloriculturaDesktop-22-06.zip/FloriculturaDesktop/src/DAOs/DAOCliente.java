
package DAOs;

import static DAOs.DAOGenerico.em;
import Entidades.Cliente;
import java.util.ArrayList;
import java.util.List;

public class DAOCliente extends DAOGenerico<Cliente> {

    public DAOCliente() {
        super(Cliente.class);
    }

    public int autoIdCliente() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idCliente) FROM Cliente e").getSingleResult();

        if (a != null) {

            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Cliente> listById(int id) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.idCliente = :id").setParameter("id", id).getResultList();
    }

    public List<Cliente> listInOrderId() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.idCliente").getResultList();
    }
    public List<Cliente> listByLogin(String login) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.loginCliente = :login").setParameter("login", login).getResultList();
    }

    public List<Cliente> listInOrderLogin() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.loginCliente").getResultList();
    }

    public List<Cliente> listByCpf(String cpf) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.cpfClienteLIKE :cpf").setParameter("cpf", "%" + cpf + "%").getResultList();
    }

    public List<Cliente> listInOrderCpf() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.cpfCliente").getResultList();
    }

    public List<Cliente> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Cliente e WHERE e.nomeClienteLIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Cliente> listInOrderNome() {
        return em.createQuery("SELECT e FROM Cliente e ORDER BY e.nomeCliente").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Cliente> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }
        List<String> ls = new ArrayList<>();

        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdCliente() + "- (ID)" + lf.get(i).getCpf() + "- (CPF)" + lf.get(i).getNome() + "- (Nome)");
        }
            return ls;
        }
    
    public List<String> listStrings() {
        List<Cliente> lf = list();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(String.valueOf(lf.get(i).getIdCliente()));
        }
        return ls;
    }

    }
