package Main;

import DAOs.DAOFlor;
import Entidades.Flor;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import static java.awt.Dialog.DEFAULT_MODALITY_TYPE;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

/**
 *
 * @author Dotor André, Dotor Gabriel, Dotor Hideky, Dotor Sergio
 */
public class GUIFlor extends JDialog {

    private Container cp;
    private JPanel pNorte = new JPanel(new FlowLayout());
    private JPanel pCentro = new JPanel(new GridLayout(6, 2));
    private JPanel pSul = new JPanel(new FlowLayout());
    private JButton btBuscar = new JButton("Buscar");
    private JButton btInserir = new JButton("Inserir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btRemover = new JButton("Remover");
    private JButton btAtualizar = new JButton("Atualizar");
    private JButton btListar = new JButton("Listar");
    private JButton btPesq = new JButton("Pesq. Incremental");

    private SimpleDateFormat sdf_dataregistro = new SimpleDateFormat("dd/MM/yyyy");
    private DecimalFormat formatador = new DecimalFormat("0.00");
    
    Date hoje = new Date();

    Image x;
    ImageIcon ifind = new ImageIcon(getClass().getResource("/icons/find.png"));
    ImageIcon icreate = new ImageIcon(getClass().getResource("/icons/create.png"));
    ImageIcon icancel = new ImageIcon(getClass().getResource("/icons/cancelar.png"));
    ImageIcon iupdate = new ImageIcon(getClass().getResource("/icons/update.png"));
    ImageIcon isave = new ImageIcon(getClass().getResource("/icons/save.png"));
    ImageIcon iremove = new ImageIcon(getClass().getResource("/icons/delete.png"));
    private JTextField tfid = new JTextField(20);
    private JTextField tfpreco = new JTextField(20);
    private JTextField tfqtddisponivel = new JTextField(20);
    private JTextField tffornecedor = new JTextField(20);
    private JTextField tfespecie = new JTextField(20);
    private JTextField tfdataregistro = new JTextField(20);

    private JLabel lbid = new JLabel("ID");
    private JLabel lbpreco = new JLabel("Preço Unitário");
    private JLabel lbqtddisponivel = new JLabel("Quantidade Disponivel");
    private JLabel lbfornecedor = new JLabel("Nome do Fornecedor");
    private JLabel lbespecie = new JLabel("Espécie");
    private JLabel lbdataregistro = new JLabel("Data de Registro");

    private JLabel lbAviso = new JLabel("Aviso");
    DAOFlor controle = new DAOFlor();
    Flor flor = new Flor();
    boolean acao;

    ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
    List<String> dados = new ArrayList<>();

    String[] colunas = {"id", "preco", "qtddisponivel", "fornecedor", "especie", "dataregistro"};
    
            public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    public GUIFlor() {

        setSize(1000, 700);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("Cadastro de Flor");
        
        pNorte.add(btPesq);
        pNorte.add(lbid);
        pNorte.add(tfid);
        pNorte.add(btBuscar);
        pNorte.add(btInserir);
        pNorte.add(btSalvar);
        pNorte.add(btCancelar);
        pNorte.add(btRemover);
        pNorte.add(btAtualizar);
        pNorte.add(btListar);

        Image x;

        x = ifind.getImage();
        ifind.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btBuscar.setIcon(ifind);

        x = icreate.getImage();
        icreate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btInserir.setIcon(icreate);

        x = isave.getImage();
        isave.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btSalvar.setIcon(isave);

        x = icancel.getImage();
        icancel.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btCancelar.setIcon(icancel);

        x = iremove.getImage();
        iremove.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btRemover.setIcon(iremove);

        x = iupdate.getImage();
        iupdate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btAtualizar.setIcon(iupdate);

        btInserir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);
        btRemover.setVisible(false);
        btAtualizar.setVisible(false);
        
        pCentro.add(lbespecie);
        pCentro.add(tfespecie);
        tfespecie.setEnabled(false);
        
        pCentro.add(lbpreco);
        pCentro.add(tfpreco);
        tfpreco.setEnabled(false);

        pCentro.add(lbqtddisponivel);
        pCentro.add(tfqtddisponivel);
        tfqtddisponivel.setEnabled(false);

        pCentro.add(lbfornecedor);
        pCentro.add(tffornecedor);
        tffornecedor.setEnabled(false);

        

        pCentro.add(lbdataregistro);
        pCentro.add(tfdataregistro);
        tfdataregistro.setEnabled(false);

        pSul.add(lbAviso);
        cp.add(pNorte, BorderLayout.NORTH);
        cp.add(pCentro, BorderLayout.CENTER);
        cp.add(pSul, BorderLayout.SOUTH);
        
//        btPesq.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                List<String> listaAuxiliar = controle.listInOrderNomeStrings("id");
//                if (listaAuxiliar.size() > 0) {
//                    String selectedItem;
//                    selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x - getWidth() / 2 + getWidth() + 5, getBounds().y).getValorRetornado();
//                    if (!selectedItem.equals("")) {
//                        String[] aux = selectedItem.split("-");
//                        tfid.setText(aux[0]);
//                        clicarBotaoAutomaticamente(btBuscar, 0);
//                    } else {
//                        tfid.requestFocus();
//                        tfespecie.selectAll();
//                    }
//                }
//            }
//        });

        btPesq.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = controle.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem;
                    selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x - getWidth() / 2 + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        tfid.setText(aux[0]);
                        clicarBotaoAutomaticamente(btBuscar, 0);
                        btCancelar.setVisible(true);

                    } else {
                        tfid.requestFocus();
                        tfespecie.selectAll();
                    }
                }

            }
        });

        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.valueOf(tfid.getText());
                    //Seu código de validação da chave vai aqui
                    flor = controle.obter(id);
                    lbAviso.setBackground(Color.green);

                    if (flor != null) { //se encontrou

                        tfid.setText(String.valueOf(flor.getIdFlor()));

                        tfpreco.setText(String.valueOf(flor.getPreco()));

                        tfqtddisponivel.setText(String.valueOf(flor.getQntdDisponivel()));

                        tffornecedor.setText(String.valueOf(flor.getFornecedor()));

                        tfespecie.setText(String.valueOf(flor.getEspecie()));

                        tfdataregistro.setText(sdf_dataregistro.format(flor.getDataregistro()));

                        btAtualizar.setVisible(true);
                        btRemover.setVisible(true);
                        lbAviso.setBackground(Color.green);
                        lbAviso.setText("Achou na lista");

                    } else {

                        lbAviso.setText("Não achou na lista");
                        lbAviso.setBackground(Color.red);
                        btInserir.setVisible(true);
                        btAtualizar.setVisible(false);
                        btRemover.setVisible(false);
                        tfpreco.setEnabled(false);
                    tfpreco.setText("");
                    tfqtddisponivel.setEnabled(false);
                    tfqtddisponivel.setText("");
                    tffornecedor.setEnabled(false);
                    tffornecedor.setText("");
                    tfespecie.setEnabled(false);
                    tfespecie.setText("");
                    tfdataregistro.setEnabled(false);
                    tfdataregistro.setText("");
                    tfid.setEnabled(true);

                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    }

                } catch (Exception err) {
                    lbAviso.setText("Erro nos dados");
                    lbAviso.setBackground(Color.red);
                }

            }
        }
        );
        btInserir.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = true;
                btBuscar.setVisible(false);
                tfpreco.setEnabled(true);
                tfqtddisponivel.setEnabled(true);
                tffornecedor.setEnabled(true);
                tfespecie.setEnabled(true);
                tfdataregistro.setEnabled(true);
                tfid.setEnabled(false);
                tfdataregistro.setText(sdf_dataregistro.format(hoje));

                btInserir.setVisible(false);
                btRemover.setVisible(false);
                btAtualizar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
            }
        }
        );
        btSalvar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    if (tfid.getText().equals("") || verificaEntrada(";")) {
                        int erro = 1 / 0;
                    }
                    
                    
                    
                    
                    Flor florNovo = new Flor(Integer.valueOf(tfid.getText()), Double.valueOf(tfpreco.getText()), Integer.valueOf(tfqtddisponivel.getText()), String.valueOf(tffornecedor.getText()), String.valueOf(tfespecie.getText()), sdf_dataregistro.parse(tfdataregistro.getText()));

                    if ((tfdataregistro.getText()).matches("^[0-9/]+$"))  {
                        lbAviso.setText("Boa, colocou a data certinha dessa vez em");
                    } else {
                        int erro = 323232 / 0;
                    }
                    
                    

                    if (acao) {

                        controle.inserir(florNovo);
                        lbAviso.setText("Registro inserido");

                    } else {
                        controle.atualizar(florNovo);
                        lbAviso.setText("Registro alterado");

                    }

                    tfpreco.setEnabled(false);
                    tfpreco.setText("");
                    tfqtddisponivel.setEnabled(false);
                    tfqtddisponivel.setText("");
                    tffornecedor.setEnabled(false);
                    tffornecedor.setText("");
                    tfespecie.setEnabled(false);
                    tfespecie.setText("");
                    tfdataregistro.setEnabled(false);
                    tfdataregistro.setText("");
                    tfid.setEnabled(true);

                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);

                } catch (Exception ex) {
                    lbAviso.setText("Erro nos dados");
                }
            }
        }
        );
        btCancelar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                lbAviso.setText("Cancelado");
                tfid.setEnabled(true);
                tfid.requestFocus();
                tfid.selectAll();

                tfpreco.setEnabled(false);
                tfpreco.setText("");
                tfqtddisponivel.setEnabled(false);
                tfqtddisponivel.setText("");
                tffornecedor.setEnabled(false);
                tffornecedor.setText("");
                tfespecie.setEnabled(false);
                tfespecie.setText("");
                tfdataregistro.setEnabled(false);
                tfdataregistro.setText("");

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
            }
        }
        );
        btAtualizar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                acao = false;
                tfid.setEnabled(true);

                tfpreco.setEnabled(true);
                tfqtddisponivel.setEnabled(true);
                tffornecedor.setEnabled(true);
                tfespecie.setEnabled(true);
                tfdataregistro.setEnabled(true);

                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btRemover.setVisible(false);
                btAtualizar.setVisible(false);

            }
        }
        );
        btRemover.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
                        "Confirma a exclusão do registro?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {

                    controle.remover(flor);
                    lbAviso.setText("Removeu");

                    tfpreco.setText("");
                    tfqtddisponivel.setText("");
                    tffornecedor.setText("");
                    tfespecie.setText("");
                    tfdataregistro.setText("");
                    btRemover.setVisible(false);
                    btAtualizar.setVisible(false);
                    tfid.setEnabled(true);
                    tfid.requestFocus();
                    tfid.setText("");

                } else {
                    lbAviso.setText("Cancelada a remoção");
                }

            }
        }
        );
        btListar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                new GUIListagemFlor(controle.list());
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dados.clear();
                List<Flor> listaFlor = controle.list();
                for (Flor a : listaFlor) {
                    dados.add(a.toString());
                }
                
            }
        });
        setLocationRelativeTo(null);
        setModalityType(DEFAULT_MODALITY_TYPE);
        setVisible(true);
    }

    private boolean verificaEntrada(String verificar) {
        String a = "";

        a += tfid.getText();
        a += tfpreco.getText();
        a += tfqtddisponivel.getText();
        a += tffornecedor.getText();
        a += tfespecie.getText();
        a += tfdataregistro.getText();

        return a.contains(verificar);
    }
}
