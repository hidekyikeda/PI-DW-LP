function validacaoCarrinho() {
    if (document.form.rosabranca.value == null && document.form.rosabranca.value == "") {
        alert("Campo \"Rosa Branca\" obrigatório.")
        document.form.rosabranca.focus();
        return false;
    }
    if (document.form.violeta.value == null && document.form.violeta.value == "") {
        alert("Campo \"Violeta\" obrigatório.");
        document.form.violeta.focus();
        return false;
    }
    if (document.form.rosavermelha.value == null && document.form.rosavermelha.value == "") {
        alert("Campo \"Rosa Vermelha\" obrigatório.");
        document.form.rosavermelha.focus();
        return false;
    }
}
