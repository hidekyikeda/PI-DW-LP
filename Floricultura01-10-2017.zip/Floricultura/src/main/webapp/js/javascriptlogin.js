function validacaoLogin() {
    if (document.form.login.value == "") {
        alert("Campo \"Login\" obrigatório.");
        document.form.login.focus();
        return false;
    }
    if (validacaoLogin().form.senha.value == "") {
        alert("Campo \"Senha\" obrigatório.");
        document.form.senha.focus();
        return false;
    }
}