/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1.controller;

import DAOs.DAOCliente;
import DAOs.DAOCompra;
import DAOs.DAOFlor;
import Entidades.Cliente;
import Entidades.Flor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Hideky
 */
@WebServlet(name = "Compra", urlPatterns = {"/Compra"})
public class Compra extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            DAOCliente controleCliente = new DAOCliente();
            Cliente cliente = new Cliente();
            DAOCompra controleCompra = new DAOCompra();
            Compra compra = new Compra();
            DAOFlor controleFlor = new DAOFlor();
            Flor flor = new Flor();
            List<String> lista_cliente = controleCliente.listStrings();
            
            
            RequestDispatcher rd = request.getRequestDispatcher("carrinho.jsp");
            RequestDispatcher finaliza = request.getRequestDispatcher("carrinho.jsp");

            rd.forward(request, response);

            String rosaBranca = request.getParameter("Rosa Branca");
            String Violeta = request.getParameter("Violeta");
            String rosaVermelha = request.getParameter("Rosa Vermelha");

            int qtdRosaVermelha = Integer.valueOf(rosaVermelha);
            int qtdRosaBranca = Integer.valueOf(rosaBranca);
            int qtdVioleta = Integer.valueOf(Violeta);

            double precoRosaVermelha = 0;
            double precoRosaBranca = 0;
            double precoVioleta = 0;
            
            String proibidos = "[+&amp;@#$/%?'\"=~_()|!:,.;]";
            List<String> lista_flor = controleFlor.listStrings();

            for (int i = 0; i < lista_flor.size() - 1; i++) {

                Flor especies = controleFlor.obter(Integer.valueOf(lista_flor.get(i)));

                if (especies.getEspecie().equals("Rosa Branca")) {
                    if ((especies.getQntdDisponivel()) <= qtdRosaBranca) {
                        precoRosaBranca = (flor.getPreco()) * (qtdRosaBranca);
                    }
                    
                }
                if (especies.getEspecie().equals("Rosa Vermelha")) {
                    if ((especies.getQntdDisponivel()) <= qtdRosaVermelha) {
                        precoRosaVermelha = (flor.getPreco()) * (qtdRosaVermelha);
                    }
                }
                if (especies.getEspecie().equals("Violeta")) {
                    if ((especies.getQntdDisponivel()) <= qtdVioleta) {
                        precoVioleta = (flor.getPreco()) * (qtdVioleta);
                    }
                }
            }
            double precoTotal = precoVioleta + precoRosaVermelha + precoRosaBranca;
            finaliza.forward(request, response);
            
            
            for(int i = 0; i < lista_cliente.size()-1; i++){
                
                Cliente cliente_existente = controleCliente.obter(Integer.valueOf(lista_cliente.get(i)));
                
//                if(String.valueOf((cliente_existente.getLogin())).equals(String.valueOf(login)) && (String.valueOf(cliente_existente.getSenha()).equals(String.valueOf(senha)))){                    
//                    rd.forward(request, response);
//                
//                
//            }
                HttpSession sessao = request.getSession();
                cliente.setDivida(precoTotal);
            
            
        }
//        response.setContentType("text/html;charset=UTF-8");
        //request.setAttribute("cliente", list());
        
    }}

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}// </editor-fold>

