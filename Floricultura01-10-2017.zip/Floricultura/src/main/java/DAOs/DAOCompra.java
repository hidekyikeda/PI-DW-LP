package DAOs;

import static DAOs.DAOGenerico.em;
import Entidades.Compra;
import java.util.ArrayList;
import java.util.List;

public class DAOCompra extends DAOGenerico<Compra> {

    public DAOCompra() {
        super(Compra.class);
    }

    public int autoIdCompra() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idCompra) FROM Compra e").getSingleResult();

        if (a != null) {

            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Compra> listById(int id) {
        return em.createQuery("SELECT e FROM Compra e WHERE e.idCompra = :id").setParameter("id", id).getResultList();
    }

    public List<Compra> listInOrderId() {
        return em.createQuery("SELECT e FROM Compra e ORDER BY e.idCompra").getResultList();
    }

    public List<Compra> listByClienteid(int clienteid) {
        return em.createQuery("SELECT e FROM Compra e WHERE e.clienteidCompra = :clienteid").setParameter("clienteid", clienteid).getResultList();
    }

    public List<Compra> listInOrderClienteid() {
        return em.createQuery("SELECT e FROM Compra e ORDER BY e.clienteidCompra").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Compra> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderClienteid();
        }
        List<String> ls = new ArrayList<>();

        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdCompra() + "- (ID)" + lf.get(i).getCompra() + "- (CPF)" + lf.get(i).getClienteId() + "- (ID Cliente)");
        }
            return ls;
        }

    public List<String> listStrings() {
        List<Compra> lf = list();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(String.valueOf(lf.get(i).getIdCompra()));
        }
        return ls;
    }
}
