package Main;

import DAOs.DAOFlor;
import Entidades.Flor;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class CompraHasFlorTableModel extends AbstractTableModel {

    private final Class classes[] = new Class[]{Integer.class, Double.class, Integer.class};
    private final String colunas[] = new String[]{"FLOR", "PRECO UNITARIO", "QUANTIDADE"};
    private List<CompraHasFlorJT> dados;

    public boolean mudou = false;

    public CompraHasFlorTableModel(List<CompraHasFlorJT> dados) {
        this.dados = dados;
    }

    public void setDados(List<CompraHasFlorJT> dados) {
        this.dados = dados;
    }

    public List<CompraHasFlorJT> getDados() {
        return this.dados;
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public int getRowCount() {
        return dados.size();
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return classes[columnIndex];
    }

    @Override
    public String getColumnName(int columnIndex) {
        return colunas[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        CompraHasFlorJT s = dados.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return s.getCompraIdCompra();

            case 1:
                return s.getFlorIdFlor();

            case 2:
                return s.getPrecoUnit();
            
            case 3:
                return s.getQuantidade();

            default:
                throw new IndexOutOfBoundsException("Coluna Inválida!");
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return columnIndex != 0;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        
        mudou = true;
        CompraHasFlorJT s = dados.get(rowIndex);
        switch (columnIndex) {
            case 0:
                s.setCompraIdCompra((int) aValue);
                break;
            case 1:
                DAOFlor daoFlor = new DAOFlor();
                Flor a = daoFlor.obter((int) aValue );
                if (a != null) {
                    s.setFlorIdFlor((int) aValue);
                } else {
                    try {
                        System.out.println("erro, flor não cadastrada");
                    } catch (Exception e) {
                    }

                }

                break;
            
            case 2:
                s.setPrecoUnit((double) aValue);
                break;
    
            
            case 3:
                s.setQuantidade((int) aValue);
                break;

            default:
                throw new IndexOutOfBoundsException("Coluna Inválida!!!");

        }
        fireTableDataChanged();
    }

    public CompraHasFlorJT getValue(int rowIndex) {
        return dados.get(rowIndex);
    }

    public int indexOf(CompraHasFlorJT comprahasflor) {
        return dados.indexOf(comprahasflor);
    }

    public void onAdd(CompraHasFlorJT comprahasflor) {
        dados.add(comprahasflor);
        fireTableRowsInserted(indexOf(comprahasflor), indexOf(comprahasflor));
        mudou = true;
    }

    public void onRemove(int[] rowIndex) {
        int x;
        for (x = rowIndex.length - 1; x >= 0; x--) {
            dados.remove(rowIndex[x]);
            fireTableRowsDeleted(rowIndex[x], rowIndex[x]);
        }
        mudou = true;
    }

}
