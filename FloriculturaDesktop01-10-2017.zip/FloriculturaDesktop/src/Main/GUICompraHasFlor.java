package Main;

import DAOs.DAOCompra;
import DAOs.DAOCompraHasFlor;
import DAOs.DAOFlor;
import Entidades.Compra;
import Entidades.CompraHasFlor;
import Entidades.CompraHasFlorPK;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class GUICompraHasFlor extends JFrame {

    private Container cp;
    private JPanel painelNorte = new JPanel(new FlowLayout(FlowLayout.LEFT));
    private JPanel painelCentro = new JPanel(new GridLayout(1, 3));
    private JPanel painelSul = new JPanel();

    private JLabel labelAviso = new JLabel("");

    private JButton btBuscar = new JButton("Buscar");

    private JTextArea txtFlor = new JTextArea("");
    private JTextArea txtQtd = new JTextArea("");
    private JTextArea txtPreco = new JTextArea("");
    private JComboBox cbxCompra = new JComboBox();
    List<CompraHasFlor> listCompraHasFlor = new ArrayList<>();

    Image x;
    ImageIcon ifind = new ImageIcon(getClass().getResource("/icons/find.png"));
    ImageIcon icreate = new ImageIcon(getClass().getResource("/icons/create.png"));
    ImageIcon icancel = new ImageIcon(getClass().getResource("/icons/cancelar.png"));
    ImageIcon iupdate = new ImageIcon(getClass().getResource("/icons/update.png"));
    ImageIcon isave = new ImageIcon(getClass().getResource("/icons/save.png"));
    ImageIcon iremove = new ImageIcon(getClass().getResource("/icons/delete.png"));

    CompraHasFlorPK compraHasFlorPK = new CompraHasFlorPK();
    CompraHasFlor compraHasFlor = new CompraHasFlor();
    DAOCompraHasFlor controleCompraHasFlor = new DAOCompraHasFlor();
    DAOFlor controleFlor = new DAOFlor();
    DAOCompra controleCompra = new DAOCompra();
    Compra compra = new Compra();

    public GUICompraHasFlor() {

        setSize(800, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Escolher uma compra e gerenciar flores que pertencem a ele");

        List<Compra> comboCompra = controleCompra.listInOrderId();

        for (Compra compra : comboCompra) {
            cbxCompra.addItem(compra.getIdCompra());
        }

        painelNorte.add(cbxCompra);
        painelNorte.add(btBuscar);

        painelCentro.add(new JScrollPane(txtFlor));
        painelCentro.add(new JScrollPane(txtPreco));
        painelCentro.add(new JScrollPane(txtQtd));

        painelSul.add(labelAviso);

        Image x;

        x = ifind.getImage();
        ifind.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btBuscar.setIcon(ifind);

        txtFlor.setEditable(false);
        txtPreco.setEditable(false);
        txtQtd.setEditable(false);

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(painelNorte, BorderLayout.NORTH);
        cp.add(painelCentro, BorderLayout.CENTER);
        cp.add(painelSul, BorderLayout.SOUTH);

        txtFlor.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent Me) {
                compra.setIdCompra(Integer.valueOf(cbxCompra.getSelectedItem() + ""));
                GUICompraHasFlorCRUD guiCrudizinho = new GUICompraHasFlorCRUD(compra.getIdCompra());
            }
        });
        txtPreco.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent Me) {
                compra.setIdCompra(Integer.valueOf(cbxCompra.getSelectedItem() + ""));
                GUICompraHasFlorCRUD guiCrudizinho = new GUICompraHasFlorCRUD(compra.getIdCompra());
            }
        });
        txtQtd.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent Me) {
                compra.setIdCompra(Integer.valueOf(cbxCompra.getSelectedItem() + ""));
                GUICompraHasFlorCRUD guiCrudizinho = new GUICompraHasFlorCRUD(compra.getIdCompra());
            }
        });

        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.valueOf(cbxCompra.getSelectedItem() + "");
                    System.out.println(id);
                    //Seu código de validação da chave vai aqui
                    compra = controleCompra.obter(id);
                    System.out.println("compra: " + compra);

                    if (compra != null) { //se encontrou
                        updatetxt(compra.getIdCompra());
                    } else {
                        btBuscar.setVisible(true);
                    }

                } catch (Exception err) {

                }

            }
        }
        );

        setVisible(true);
    }

    private void updatetxt(int idCompra) {
        txtFlor.setText("");
        txtPreco.setText("");
        txtQtd.setText("");
        listCompraHasFlor = controleCompraHasFlor.listInOrderNome();
        for (CompraHasFlor a : listCompraHasFlor) {
            if (a.getCompraHasFlorPK().getCompraIdcompra() == idCompra) {
                txtFlor.append(a.getFlor().getEspecie() + "\n");
                txtPreco.append(a.getPrecoUnit() + "\n");
                txtQtd.append(a.getQtd() + "\n");
            }
        }
    }
}
