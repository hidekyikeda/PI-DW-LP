package Main;

import DAOs.DAOCompra;
import DAOs.DAOCompraHasFlor;
import DAOs.DAOCompraHasFlorPK;
import DAOs.DAOFlor;
import Entidades.Compra;
import Entidades.CompraHasFlor;
import Entidades.CompraHasFlorPK;
import Entidades.Flor;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import static java.awt.Dialog.DEFAULT_MODALITY_TYPE;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JDialog;

/**
 *
 * @author Dotor André, Dotor Gabriel, Dotor Hideky, Dotor Sergio
 */
public class GUICompraHasFlorCRUD extends JDialog {

    private Container cp;
    private JPanel pNorte = new JPanel(new FlowLayout());
    private JPanel pCentro = new JPanel(new GridLayout(9, 2));
    private JPanel pSul = new JPanel(new FlowLayout());
    private JPanel pLeste = new JPanel(new FlowLayout());
    private JButton btBuscar = new JButton("Buscar");
    private JButton btInserir = new JButton("Inserir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btRemover = new JButton("Remover");

    private JButton btListar = new JButton("Listar");

    Image x;
    ImageIcon ifind = new ImageIcon(getClass().getResource("/icons/find.png"));
    ImageIcon icreate = new ImageIcon(getClass().getResource("/icons/create.png"));
    ImageIcon icancel = new ImageIcon(getClass().getResource("/icons/cancelar.png"));
    ImageIcon iupdate = new ImageIcon(getClass().getResource("/icons/update.png"));
    ImageIcon isave = new ImageIcon(getClass().getResource("/icons/save.png"));
    ImageIcon iremove = new ImageIcon(getClass().getResource("/icons/delete.png"));
    private JComboBox cbxFlor = new JComboBox();
    private JTextField tfprecounit = new JTextField(20);
    private JTextField tfqtd = new JTextField(20);

    private JLabel lbid = new JLabel("ID da Flor");
    private JLabel lbprecounit = new JLabel("Preco Unitário");
    private JLabel lbqtd = new JLabel("Quantidade Desejada");

    private JLabel lbAviso = new JLabel("Aviso");
    DAOCompra controleCompra = new DAOCompra();
    DAOFlor controleFlor = new DAOFlor();
    DAOCompraHasFlor controleCompraHasFlor = new DAOCompraHasFlor();
    DAOCompraHasFlorPK controleCompraHasFlorPK = new DAOCompraHasFlorPK();

    CompraHasFlorPK CompraHasFlorPK = new CompraHasFlorPK();
    CompraHasFlor CompraHasFlor = new CompraHasFlor();

    ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
    List<String> dados = new ArrayList<>();

    Compra compra = new Compra();

    String[] colunas = {"id", "precounit", "qtd"};

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }
    Flor flor = new Flor();
    DAOFlor daoFlor = new DAOFlor();
    double precoTotal = 0;
    int florTotal = 0;

    public GUICompraHasFlorCRUD(int idCompra) {

        List<Flor> comboFlor = controleFlor.listInOrderId();

        for (Flor flor : comboFlor) {
            cbxFlor.addItem("Nome: " + flor.getEspecie() + " ID: " + flor.getIdFlor());
        }

        setSize(1000, 700);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("Cadastro das Flores na Compra");
        setResizable(false);

        pNorte.add(lbid);
        pNorte.add(cbxFlor);
        pNorte.add(btBuscar);
        pNorte.add(btInserir);
        pNorte.add(btSalvar);
        pNorte.add(btCancelar);
        pNorte.add(btRemover);

        pNorte.add(btListar);

        Image x;

        x = ifind.getImage();
        ifind.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btBuscar.setIcon(ifind);

        x = icreate.getImage();
        icreate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btInserir.setIcon(icreate);

        x = isave.getImage();
        isave.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btSalvar.setIcon(isave);

        x = icancel.getImage();
        icancel.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btCancelar.setIcon(icancel);

        x = iremove.getImage();
        iremove.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btRemover.setIcon(iremove);

        x = iupdate.getImage();
        iupdate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        iupdate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));

        btInserir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);
        btRemover.setVisible(false);

        pCentro.add(lbqtd);
        pCentro.add(tfqtd);
        tfqtd.setEnabled(false);

        pCentro.add(lbprecounit);
        pCentro.add(tfprecounit);
        tfprecounit.setEnabled(false);

        pSul.add(lbAviso);
        cp.add(pNorte, BorderLayout.NORTH);
        cp.add(pCentro, BorderLayout.CENTER);
        cp.add(pSul, BorderLayout.SOUTH);

        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    String aux = cbxFlor.getSelectedItem().toString();
                    aux = aux.replaceAll(" ", "");
                    aux = aux.substring(aux.lastIndexOf(":") + 1);

                    int id = Integer.valueOf(aux);
                    flor = daoFlor.obter(id);
                    //Seu código de validação da chave vai aqui
                    
                    CompraHasFlor compraHasFlor = new CompraHasFlor(idCompra, id);
                    
                    
                    
                    lbAviso.setBackground(Color.green);

                    System.out.println("comprahasflor " + CompraHasFlor);

                    if (flor != null) { //se encontrou
                        
                        cbxFlor.setSelectedItem(String.valueOf(flor.getIdFlor()));

                        tfprecounit.setText(String.valueOf(flor.getPreco()));

                        tfqtd.setText(String.valueOf(CompraHasFlor.getQtd()));
                        
                        tfqtd.setEnabled(true);
                        btSalvar.setVisible(true);
                        btCancelar.setVisible(false);
                        btBuscar.setVisible(true);
                        btRemover.setVisible(true);
                        btInserir.setVisible(false);

                        lbAviso.setBackground(Color.green);
                        lbAviso.setText("Achou na lista");

                    } else {

                        lbAviso.setText("Não achou na lista");
                        lbAviso.setBackground(Color.red);
                        tfprecounit.setEnabled(false);
                        tfprecounit.setText("");
                        tfqtd.setEnabled(false);
                        tfqtd.setText("Digite a quantidade de flores: (" + flor.getQntdDisponivel() + " à dispor)).");

                        cbxFlor.setEnabled(true);

                        btSalvar.setVisible(false);
                        btCancelar.setVisible(false);
                        btBuscar.setVisible(true);
                        btRemover.setVisible(false);
                        btInserir.setVisible(true);

                    }

                } catch (Exception err) {
                    System.out.println(err);
                    lbAviso.setText("Erro nos dados na hora de buscar.");
                    lbAviso.setBackground(Color.red);
                }

            }
        }
        );

        btInserir.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                tfprecounit.setEnabled(true);
                tfqtd.setEnabled(true);
                cbxFlor.setEnabled(false);

                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btRemover.setVisible(false);
                btInserir.setVisible(false);

            }
        }
        );

        btSalvar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    String aux = cbxFlor.getSelectedItem().toString();
                    aux = aux.replaceAll(" ", "");
                    aux = aux.substring(aux.lastIndexOf(":") + 1);
                    int aux2 = Integer.valueOf(aux);

                    CompraHasFlorPK compraHasFlorPK = new CompraHasFlorPK(idCompra, aux2);

                    int quantidade = Integer.valueOf(tfqtd.getText());

                    if (quantidade > flor.getQntdDisponivel()) {
                        int erro = 666 / 0;
                    }

                    double precounit = Double.valueOf(tfprecounit.getText());

                    CompraHasFlor CompraHasFlorNovo = new CompraHasFlor(compraHasFlorPK, quantidade, precounit);
                    System.out.println(CompraHasFlorNovo.getQtd());
                    precoTotal = quantidade * precounit;

                    Compra compraNovo = controleCompra.obter(idCompra);
                    precoTotal += compraNovo.getCompra();
                    compraNovo.setCompra(precoTotal);

                    Flor florNovo = controleFlor.obter(aux2);
                    
                    florTotal = florNovo.getQntdDisponivel();
                    florNovo.setQntdDisponivel(florTotal - quantidade);
                    
                    
                    

                    //Compra compraNovo = new Compra(Integer.valueOf(tfid.getText()), Double.valueOf(tfcompra.getText()), sdf_data.parse(tfdata.getText()), (controleCliente.obter(Integer.valueOf(aux))), (controleDestinatario.obter(Integer.valueOf(aux2))));
                    controleCompraHasFlor.inserir(CompraHasFlorNovo);
                    lbAviso.setText("Registro inserido");

                    tfprecounit.setEnabled(false);
                    tfprecounit.setText("");
                    tfqtd.setEnabled(false);
                    tfqtd.setText("");
                    cbxFlor.setEnabled(true);

                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btRemover.setVisible(false);
                    btInserir.setVisible(false);

                } catch (Exception ex) {
                    String aux = cbxFlor.getSelectedItem().toString();
                    aux = aux.replaceAll(" ", "");
                    aux = aux.substring(aux.lastIndexOf(":") + 1);
                    int aux2 = Integer.valueOf(aux);
                    Flor flor = controleFlor.obter(aux2);                    
                    lbAviso.setText("Quantidade disponível (" + flor.getQntdDisponivel() + ") deve ser maior ou igual à quantidade desejada.");
                    tfqtd.requestFocus();
                    ex.printStackTrace();
                }
            }
        }
        );
        btCancelar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                lbAviso.setText("Cancelado");
                cbxFlor.setEnabled(true);
                cbxFlor.requestFocus();

                tfprecounit.setEnabled(false);
                tfprecounit.setText("");
                tfqtd.setEnabled(false);
                tfqtd.setText("");

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btRemover.setVisible(true);
                btInserir.setVisible(false);

            }
        }
        );

        btRemover.addActionListener((ActionEvent e) -> {
            if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
                    "Confirma a exclusão do registro?", "Confirm",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {

                controleCompra.remover(compra);
                lbAviso.setText("Removeu");

                tfprecounit.setText("");
                tfqtd.setText("");

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btRemover.setVisible(false);
                btInserir.setVisible(false);

                cbxFlor.setEnabled(true);
                cbxFlor.requestFocus();
                cbxFlor.setSelectedIndex(0);

            } else {
                lbAviso.setText("Cancelada a remoção");
            }
        });
        btListar.addActionListener((ActionEvent e) -> {
            new GUIListagemCompra(controleCompra.list());
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dados.clear();
                List<Compra> listaCompra = controleCompra.list();
                for (Compra a : listaCompra) {
                    dados.add(a.toString());
                }

            }
        });
        setLocationRelativeTo(null);
        setModalityType(DEFAULT_MODALITY_TYPE);
        setVisible(true);
    }

    private boolean verificaEntrada(String verificar) {
        String a = "";

        a += cbxFlor.getSelectedItem();
        a += tfprecounit.getText();
        a += tfqtd.getText();

        return a.contains(verificar);
    }
}
