package Main;

public class CompraHasFlorJT implements java.io.Serializable {

    private int compraIdCompra;
    private int florIdFlor;
    private double precoUnit;
    private int quantidade;

    //--------construtores----------
    public CompraHasFlorJT() {
    }

    public CompraHasFlorJT(int compraIdCompra, int florIdFlor, double precoUnit,int quantidade) {
        this.compraIdCompra = compraIdCompra;
        this.florIdFlor = florIdFlor;
        this.precoUnit = precoUnit;
        this.quantidade = quantidade;
    }

    //--------métodos set----------
    public void setCompraIdCompra(int compraIdCompra) {
        this.compraIdCompra = compraIdCompra;
    }

    public void setFlorIdFlor(int florIdFlor) {
        this.florIdFlor = florIdFlor;
    }
    
    public void setPrecoUnit(double precoUnit) {
        this.precoUnit = precoUnit;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    //--------métodos get----------
    public int getCompraIdCompra() {
        return this.compraIdCompra;
    }

    public int getFlorIdFlor() {
        return this.florIdFlor;
    }
    
    public double getPrecoUnit() {
        return this.precoUnit;
    }

    public int getQuantidade() {
        return this.quantidade;
    }

    //--------método toString----------
    @Override
    public String toString() {

        return this.compraIdCompra + ";" + this.florIdFlor + ";" + this.precoUnit + ";" + this.quantidade;
    }
}
