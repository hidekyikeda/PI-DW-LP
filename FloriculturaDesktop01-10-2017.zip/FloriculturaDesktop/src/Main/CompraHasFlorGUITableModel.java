package Main;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JOptionPane;


public class CompraHasFlorGUITableModel extends JFrame {

    private final Container cp;
    private final JPanel painelBotoes = new JPanel();
    private final JButton btnAdd = new JButton("Adicionar");
    private final JButton btnRem = new JButton("Remover");
    private final JButton btnCarregar = new JButton("Carregar dados");
    private JButton btnSalvar = new JButton("Salvar dados");
    private JTable table = new JTable();
    private CompraHasFlorTableModel tableModel;

    public CompraHasFlorGUITableModel() {

        setTitle("CRUD TableModel");
        setLayout(new FlowLayout());
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(BorderLayout.NORTH, painelBotoes);

        List<CompraHasFlorJT> lista = new ArrayList<>();
        tableModel = new CompraHasFlorTableModel(lista);
        table.setModel(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        cp.add(scrollPane);

        painelBotoes.add(btnAdd);
        painelBotoes.add(btnRem);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnCarregar);

        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(WindowEvent winEvt) {
                if (tableModel.mudou) {
                    int response = JOptionPane.showConfirmDialog(cp, "Deseja salvar as informações?", "Info",
                            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (response == JOptionPane.YES_OPTION) {
                        btnSalvar.doClick();
                    }
                    System.exit(0);
                }
            }
        });

        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tableModel.onAdd(new CompraHasFlorJT(0, 0, 0, 0));
            }
        });

        btnRem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (table.getSelectedRow() != -1 && table.getSelectedRow() < tableModel.getRowCount()) {
                    tableModel.onRemove(table.getSelectedRows());
                }
            }
        });

        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    FileOutputStream fos = new FileOutputStream("arquivo.dat");
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(tableModel.getDados());
                    oos.close();
                    fos.close();
                    tableModel.mudou = false;

                } catch (IOException ioe) {
                    System.out.println("Erro ao salvar...");
                }
            }
        });

        btnCarregar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                File f = new File("arquivo.dat");
                if (f.exists() && !f.isDirectory()) {
                    try {
                        FileInputStream fis = new FileInputStream("arquivo.dat");
                        ObjectInputStream ois = new ObjectInputStream(fis);
                        tableModel.setDados((List<CompraHasFlorJT>) ois.readObject());
                        tableModel.fireTableDataChanged();
                        ois.close();
                        fis.close();
                    } catch (IOException | ClassNotFoundException ex) {
                        System.out.println("Erro ao carregar o arquivo..." + ex.getMessage());
                    }
                }
            }
        });

        
        setLocation(null);
        setVisible(true);

    }//fim do construtor -------------------

}
