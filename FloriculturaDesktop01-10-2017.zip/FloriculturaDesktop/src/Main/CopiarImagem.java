package Main;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import javax.swing.ImageIcon;

/**
 *
 * @author Dotor André, Dotor Gabriel, Dotor Hideky, Dotor Sergio (Edited by: Dotor Madheus Koriyama)
 */

public class CopiarImagem {

    public static void copiar(String origem, String destino) {
        System.out.println("Origem >" + origem + " Destino >" + destino);
        try {
            InputStream in;
            in = new FileInputStream(origem);
            OutputStream out;
            byte[] buf = new byte[1024];
            out = new FileOutputStream(destino);
            int len;
            try {
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            } catch (IOException ex) {
                System.out.println("Erro na cópia");
            }
            try {
                in.close();
                out.close();
            } catch (IOException ex) {
                System.out.println("Erro na cópia");
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Erro na cópia - arquivo não encontrado");
        }
    }

    public String MoverImagem(String origem, String destino, String id, String oldImg) throws Exception {
        try {
            File source = new File(origem);
            File dest = new File(destino + origem.substring(origem.lastIndexOf("\\")));
            Files.copy(source.toPath(), dest.toPath());

            File name = new File(dest.getAbsolutePath());
            String Dest = dest.getAbsolutePath();
            File rename = new File(Dest.substring(0, Dest.lastIndexOf("\\")) + "\\" + id + Dest.substring(Dest.lastIndexOf(".")));
            if (oldImg != null) {
                DeletarImagem(oldImg);
            }
            Files.copy(name.toPath(), rename.toPath());

            DeletarImagem(name.getAbsolutePath());

            return rename.getAbsolutePath().substring(String.valueOf(rename).lastIndexOf("src"));
        } catch (Exception img) {
            System.out.println("MoverImagem Error: " + img);
            return null;
        }
    }

    public void DeletarImagem(String origem) {
        try {
            File img = new File(origem);
            Files.delete(img.toPath());
        } catch (Exception img) {
            System.out.println("DeletarImagem Error: " + img);
        }
    }

    public Image GetImg(String origem, int x, int y) {
        ImageIcon imgIcone = new ImageIcon(origem);
        Image iIcone = imgIcone.getImage();
        Image Icone = iIcone.getScaledInstance(x, y, java.awt.Image.SCALE_SMOOTH);
        return Icone;
    }

}
