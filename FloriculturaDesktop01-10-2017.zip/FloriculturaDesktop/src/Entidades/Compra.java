/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Hideky
 */
@Entity
@Table(name = "compra")
@NamedQueries({
    @NamedQuery(name = "Compra.findAll", query = "SELECT c FROM Compra c")})
public class Compra implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_compra")
    private Integer idCompra;
    @Basic(optional = false)
    @Column(name = "compra")
    private double compra;
    @Basic(optional = false)
    @Column(name = "data")
    @Temporal(TemporalType.DATE)
    private Date data;
    @JoinColumn(name = "cliente_id", referencedColumnName = "id_cliente")
    @ManyToOne(optional = false)
    private Cliente clienteId;
    @JoinColumn(name = "destinatario_id_destinatario", referencedColumnName = "id_destinatario")
    @ManyToOne(optional = false)
    private Destinatario destinatarioIdDestinatario;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "compra")
    private List<CompraHasFlor> compraHasFlorList;

    public Compra() {
    }

    public Compra(Integer idCompra) {
        this.idCompra = idCompra;
    }

    public Compra(Integer idCompra, double compra, Date data, Cliente clienteId, Destinatario destinatarioIdDestinatario) {
        this.idCompra = idCompra;
        this.compra = compra;
        this.data = data;
        this.clienteId = clienteId;
        this.destinatarioIdDestinatario = destinatarioIdDestinatario;
    }

    public Integer getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(Integer idCompra) {
        this.idCompra = idCompra;
    }

    public double getCompra() {
        return compra;
    }

    public void setCompra(double compra) {
        this.compra = compra;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Cliente getClienteId() {
        return clienteId;
    }

    public void setClienteId(Cliente clienteId) {
        this.clienteId = clienteId;
    }

    public Destinatario getDestinatarioIdDestinatario() {
        return destinatarioIdDestinatario;
    }

    public void setDestinatarioIdDestinatario(Destinatario destinatarioIdDestinatario) {
        this.destinatarioIdDestinatario = destinatarioIdDestinatario;
    }

    public List<CompraHasFlor> getCompraHasFlorList() {
        return compraHasFlorList;
    }

    public void setCompraHasFlorList(List<CompraHasFlor> compraHasFlorList) {
        this.compraHasFlorList = compraHasFlorList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCompra != null ? idCompra.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Compra)) {
            return false;
        }
        Compra other = (Compra) object;
        if ((this.idCompra == null && other.idCompra != null) || (this.idCompra != null && !this.idCompra.equals(other.idCompra))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.Compra[ idCompra=" + idCompra + " ]";
    }
    
}
