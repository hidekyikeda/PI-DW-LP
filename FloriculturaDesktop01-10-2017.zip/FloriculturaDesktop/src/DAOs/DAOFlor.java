package DAOs;

import Entidades.Compra;
import Entidades.Flor;
import java.util.ArrayList;
import java.util.List;

public class DAOFlor extends DAOGenerico<Flor> {

    public DAOFlor() {
        super(Flor.class);
    }

    public int autoIdFlor() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idFlor) FROM Flor e").getSingleResult();

        if (a != null) {

            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Flor> listById(int id) {
        return em.createQuery("SELECT e FROM Flor e WHERE e.idFlor = :id").setParameter("id", id).getResultList();
    }

    public List<Flor> listInOrderId() {
        return em.createQuery("SELECT e FROM Flor e ORDER BY e.idFlor").getResultList();
    }
    
    public List<Flor> listByEspecie(String especie) {
        return em.createQuery("SELECT e FROM Flor e WHERE e.especieFlor = :especie").setParameter("especie", especie).getResultList();
    }

    public List<Flor> listInOrderEspecie() {
        return em.createQuery("SELECT e FROM Flor e ORDER BY e.especieFlor").getResultList();
    }

    public List<Flor> listByPreco(double preco) {
        return em.createQuery("SELECT e FROM Flor e WHERE e.precoFlor = :preco").setParameter("preco", preco).getResultList();
    }

    public List<Flor> listInOrderPreco() {
        return em.createQuery("SELECT e FROM Flor e ORDER BY e.precoFlor").getResultList();
    }
    
     public List<Compra> florHasCompra(int id) {

        return em.createQuery("SELECT cl FROM Flor p INNER JOIN p.compraList cl WHERE p.idFlor = :id").

                setParameter("id", id).getResultList();

    }
    
//    public List<Compra> florHasCompra(int id) {
//        return em.createQuery("SELECT cl FROM Flor p INNER JOIN p.compraList cl WHERE p.idFlor = :id").
//                setParameter("id", id).getResultList();
//    }

       public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Flor> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderEspecie();
        }
        List<String> ls = new ArrayList<>();

        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIdFlor() + "- (ID Flor)" + lf.get(i).getEspecie() + "- (Especie)" + lf.get(i).getPreco() + "- (Preco)");
        }
            return ls;
        }
       public List<String> listStrings() {
        List<Flor> lf = list();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(String.valueOf(lf.get(i).getIdFlor()));
        }
        return ls;
    }
}
