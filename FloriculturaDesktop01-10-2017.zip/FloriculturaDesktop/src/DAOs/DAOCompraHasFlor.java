package DAOs;

import Entidades.CompraHasFlor;
import Entidades.CompraHasFlorPK;
import static DAOs.DAOGenerico.em;
import java.util.ArrayList;
import java.util.List;

public class DAOCompraHasFlor extends DAOGenerico<CompraHasFlor> {

    public DAOCompraHasFlor() {
        super(CompraHasFlor.class);
    }

    public CompraHasFlor obter(CompraHasFlorPK compraHasFlorPk) {
        return em.find(CompraHasFlor.class, compraHasFlorPk);
    }

    public List<CompraHasFlor> listInOrderNome() {
        return em.createQuery("SELECT e FROM CompraHasFlor e ORDER BY e.flor").getResultList();
    }

    public List<String> listInOrderNomeStrings() {
        List<CompraHasFlor> lf = listInOrderNome();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getCompraHasFlorPK().toString());
        }
        return ls;
    }
}
