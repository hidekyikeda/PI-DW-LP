package Main;

import DAOs.DAOCliente;
import Entidades.Cliente;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import static java.awt.Dialog.DEFAULT_MODALITY_TYPE;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import java.text.SimpleDateFormat;
import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Dotor André, Dotor Gabriel, Dotor Hideky, Dotor Sergio
 */
public class GUICliente extends JDialog {

    private Container cp;
    private JPanel pNorte = new JPanel(new FlowLayout());
    private JPanel pCentro = new JPanel(new GridLayout(9, 2));
    private JPanel pSul = new JPanel(new FlowLayout());
    private JPanel pLeste = new JPanel(new FlowLayout());
    private JButton btBuscar = new JButton("Buscar");
    private JButton btInserir = new JButton("Inserir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btRemover = new JButton("Remover");
    private JButton btAtualizar = new JButton("Atualizar");
    private JButton btListar = new JButton("Listar");
    private JButton btPesq = new JButton("Pesq. Incremental");

    private SimpleDateFormat sdf_data = new SimpleDateFormat("dd/MM/yyyy");

    Image x;
    ImageIcon ifind = new ImageIcon(getClass().getResource("/icons/find.png"));
    ImageIcon icreate = new ImageIcon(getClass().getResource("/icons/create.png"));
    ImageIcon icancel = new ImageIcon(getClass().getResource("/icons/cancelar.png"));
    ImageIcon iupdate = new ImageIcon(getClass().getResource("/icons/update.png"));
    ImageIcon isave = new ImageIcon(getClass().getResource("/icons/save.png"));
    ImageIcon iremove = new ImageIcon(getClass().getResource("/icons/delete.png"));
    private JTextField tfid = new JTextField(20);
    private JTextField tfcpf = new JTextField(20);
    private JTextField tfnome = new JTextField(20);
    private JTextField tflogin = new JTextField(20);
    private JTextField tfsenha = new JTextField(20);
    private JTextField tfendereco = new JTextField(20);
    private JTextField tfdata = new JTextField(20);

    private JCheckBox cbadmin = new JCheckBox("sim/não");
    private JCheckBox cbativo = new JCheckBox("sim/não");

    private JLabel lbid = new JLabel("ID");
    private JLabel lbcpf = new JLabel("CPF");
    private JLabel lbnome = new JLabel("Nome");
    private JLabel lblogin = new JLabel("Login");
    private JLabel lbsenha = new JLabel("Senha");
    private JLabel lbendereco = new JLabel("Endereco");
    private JLabel lbdata = new JLabel("Data");
    private JLabel lbadmin = new JLabel("Administrador");
    private JLabel lbativo = new JLabel("Ativo");

    ImageIcon imageIcon = new ImageIcon();

    private JButton btimagem = new JButton("Selecione sua imagem");
    private JLabel lbimagem2 = new JLabel(imageIcon);

    String origem;
    String destino = "src\\img\\";
    Image imagemAux;

    boolean imgVariavel = false;

    private JLabel lbAviso = new JLabel("Aviso");
    DAOCliente controle = new DAOCliente();
    Cliente cliente = new Cliente();
    boolean acao;

    ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
    List<String> dados = new ArrayList<>();

    CopiarImagem copiarImagem = new CopiarImagem();

    String[] colunas = {"id", "nome", "cpf", "login", "senha", "endereco", "data", "admin", "ativo"};

    public void clicarBotaoAutomaticamente(AbstractButton button, int millis) {
        button.doClick(millis);//clica automaticamente um botão após millis segundos
    }

    public GUICliente() {

        sdf_data.setLenient(false);
        setSize(1000, 700);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("Cadastro de Cliente");

        pNorte.add(btPesq);
        pNorte.add(lbid);
        pNorte.add(tfid);
        pNorte.add(btBuscar);
        pNorte.add(btInserir);
        pNorte.add(btSalvar);
        pNorte.add(btCancelar);
        pNorte.add(btRemover);
        pNorte.add(btAtualizar);
        pNorte.add(btListar);

        Image x;

        x = ifind.getImage();
        ifind.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btBuscar.setIcon(ifind);

        x = icreate.getImage();
        icreate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btInserir.setIcon(icreate);

        x = isave.getImage();
        isave.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btSalvar.setIcon(isave);

        x = icancel.getImage();
        icancel.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btCancelar.setIcon(icancel);

        x = iremove.getImage();
        iremove.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btRemover.setIcon(iremove);

        x = iupdate.getImage();
        iupdate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btAtualizar.setIcon(iupdate);

        btInserir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);
        btRemover.setVisible(false);
        btAtualizar.setVisible(false);
        btimagem.setVisible(false);

        cbadmin.setEnabled(false);
        cbativo.setEnabled(false);

        pCentro.add(lbnome);
        pCentro.add(tfnome);
        tfnome.setEnabled(false);

        pCentro.add(lbcpf);
        pCentro.add(tfcpf);
        tfcpf.setEnabled(false);

        pCentro.add(lblogin);
        pCentro.add(tflogin);
        tflogin.setEnabled(false);

        pCentro.add(lbsenha);
        pCentro.add(tfsenha);
        tfsenha.setEnabled(false);

        pCentro.add(lbendereco);
        pCentro.add(tfendereco);
        tfendereco.setEnabled(false);

        pCentro.add(lbdata);
        pCentro.add(tfdata);
        tfdata.setEnabled(false);

        pCentro.add(lbadmin);
        pCentro.add(cbadmin);

        pCentro.add(lbativo);
        pCentro.add(cbativo);

        pLeste.add(btimagem);
        pLeste.add(lbimagem2);

        pSul.add(lbAviso);
        cp.add(pNorte, BorderLayout.NORTH);
        cp.add(pCentro, BorderLayout.CENTER);
        cp.add(pSul, BorderLayout.SOUTH);
        cp.add(pLeste, BorderLayout.EAST);

        btPesq.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = controle.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem;
                    selectedItem = new JanelaPesquisar(listaAuxiliar, getBounds().x - getWidth() / 2 + getWidth() + 5, getBounds().y).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        tfid.setText(aux[0]);
                        clicarBotaoAutomaticamente(btBuscar, 0);
                        btCancelar.setVisible(true);

                    } else {
                        tfid.requestFocus();
                        tfnome.selectAll();
                    }
                }

            }
        });

        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.valueOf(tfid.getText());
                    //Seu código de validação da chave vai aqui
                    cliente = controle.obter(id);
                    lbAviso.setBackground(Color.green);

                    if (cliente != null) { //se encontrou

                        tfid.setText(String.valueOf(cliente.getIdCliente()));

                        tfcpf.setText(String.valueOf(cliente.getCpf()));

                        tfnome.setText(String.valueOf(cliente.getNome()));

                        tflogin.setText(String.valueOf(cliente.getLogin()));

                        tfsenha.setText(String.valueOf(cliente.getSenha()));

                        tfendereco.setText(String.valueOf(cliente.getEndereco()));

                        tfdata.setText(sdf_data.format(cliente.getDatanascimento()));

                        cbadmin.setSelected(cliente.getAdmin());

                        cbativo.setSelected(cliente.getAtivo());

                        try {
                            imageIcon = new ImageIcon(copiarImagem.GetImg("\\img\\" + String.valueOf(cliente.getIdCliente()), 128, 128));
                        } catch (Exception ex) {
                            imageIcon = new ImageIcon(copiarImagem.GetImg("\\img\\0.png", 128, 128));
                        }

                        try {
                            String aux = String.valueOf(cliente.getIdCliente()).trim();
                            origem = "src\\img\\" + aux + ".png";
                            ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                            imagemAux = icone.getImage();
                            icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));

                            lbimagem2.setIcon(icone);

                        } catch (Exception xe) {
                            System.out.println("Não achou " + origem);
                            origem = "\\img\\0.png";
                            ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                            imagemAux = icone.getImage();
                            icone.setImage(imagemAux.getScaledInstance(600, 600, Image.SCALE_FAST));
                            lbimagem2.setIcon(icone);
                        }
                        btSalvar.setVisible(false);
                        btCancelar.setVisible(false);
                        btBuscar.setVisible(true);
                        btRemover.setVisible(true);
                        btInserir.setVisible(false);
                        btimagem.setVisible(false);
                        btAtualizar.setVisible(true);
                        lbAviso.setBackground(Color.green);
                        lbAviso.setText("Achou na lista");
                        
                    } else {

                        origem = "\\img\\0.png";
                        ImageIcon icone = new ImageIcon(getClass().getResource(origem));
                        imagemAux = icone.getImage();
                        icone.setImage(imagemAux.getScaledInstance(300, 300, Image.SCALE_FAST));
                        lbimagem2.setIcon(icone);
                        lbAviso.setText("Não achou na lista");
                        lbAviso.setBackground(Color.red);
                        tfcpf.setEnabled(false);
                        tfcpf.setText("");
                        tfnome.setEnabled(false);
                        tfnome.setText("");
                        tflogin.setEnabled(false);
                        tflogin.setText("");
                        tfsenha.setEnabled(false);
                        tfsenha.setText("");
                        tfendereco.setEnabled(false);
                        tfendereco.setText("");
                        tfdata.setEnabled(false);
                        tfdata.setText("");
                        cbadmin.setEnabled(false);
                        cbadmin.setSelected(false);
                        cbativo.setEnabled(false);
                        cbativo.setSelected(false);
                        tfid.setEnabled(true);

                        btSalvar.setVisible(false);
                        btCancelar.setVisible(false);
                        btBuscar.setVisible(true);
                        btRemover.setVisible(false);
                        btInserir.setVisible(true);
                        btimagem.setVisible(false);
                        btAtualizar.setVisible(false);

                    }

                } catch (Exception err) {
                    lbAviso.setText("Erro nos dados na hora de buscar.");
                    lbAviso.setBackground(Color.red);
                }

            }
        }
        );

        btInserir.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                imgVariavel = true;
                acao = true;

                tfcpf.setEnabled(true);
                tfnome.setEnabled(true);
                tflogin.setEnabled(true);
                tfsenha.setEnabled(true);
                tfendereco.setEnabled(true);
                tfdata.setEnabled(true);
                cbadmin.setEnabled(true);
                cbativo.setEnabled(true);
                tfid.setEnabled(false);

                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btRemover.setVisible(false);
                btInserir.setVisible(false);
                btimagem.setVisible(true);
                btAtualizar.setVisible(false);
            }
        }
        );

        btSalvar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    String data = tfdata.getText();//mudar esse txt field do caraio aqui

                    if (!data.matches("^[0-9/]+$")) {
                        int erro = 69 / 0;
                    }
                    if (tfid.getText().equals("") || verificaEntrada(";")) {
                        int erro = 1 / 0;
                    }

                    Cliente clienteNovo = new Cliente(Integer.valueOf(tfid.getText()), String.valueOf(tfnome.getText()), String.valueOf(tfcpf.getText()), String.valueOf(tflogin.getText()), String.valueOf(tfsenha.getText()), String.valueOf(tfendereco.getText()), sdf_data.parse(tfdata.getText()), cbadmin.isSelected(), cbativo.isSelected());

                    if (acao) {

                        controle.inserir(clienteNovo);
                        lbAviso.setText("Registro inserido");

                    } else {
                        controle.atualizar(clienteNovo);
                        lbAviso.setText("Registro alterado");

                    }

                    tfcpf.setEnabled(false);
                    tfcpf.setText("");
                    tfnome.setEnabled(false);
                    tfnome.setText("");
                    tflogin.setEnabled(false);
                    tflogin.setText("");
                    tfsenha.setEnabled(false);
                    tfsenha.setText("");
                    tfendereco.setEnabled(false);
                    tfendereco.setText("");
                    tfdata.setEnabled(false);
                    tfdata.setText("");
                    cbadmin.setEnabled(false);
                    cbadmin.setSelected(false);
                    cbativo.setEnabled(false);
                    cbativo.setSelected(false);
                    tfid.setEnabled(true);

                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                    btRemover.setVisible(false);
                    btInserir.setVisible(false);
                    btimagem.setVisible(false);
                    btAtualizar.setVisible(false);
                    destino = destino + cliente.getIdCliente()+ ".png";
//                    System.out.println("origem =>" + origem);
//                    System.out.println("destino =>" + destino);
                    CopiarImagem.copiar(origem, destino);
                    destino = "src/img/";
                } catch (Exception ex) {
                    lbAviso.setText("Erro nos dados");
                }
            }
        }
        );
        btCancelar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                lbAviso.setText("Cancelado");
                tfid.setEnabled(true);
                tfid.requestFocus();
                tfid.selectAll();

                tfcpf.setEnabled(false);
                tfcpf.setText("");
                tfnome.setEnabled(false);
                tfnome.setText("");
                tflogin.setEnabled(false);
                tflogin.setText("");
                tfsenha.setEnabled(false);
                tfsenha.setText("");
                tfendereco.setEnabled(false);
                tfendereco.setText("");
                tfdata.setEnabled(false);
                tfdata.setText("");
                cbadmin.setEnabled(false);
                cbadmin.setSelected(false);
                cbativo.setEnabled(false);
                cbativo.setSelected(false);

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btRemover.setVisible(true);
                btInserir.setVisible(false);
                btimagem.setVisible(false);
                btAtualizar.setVisible(false);
            }
        }
        );
        btAtualizar.addActionListener((ActionEvent e) -> {
            imgVariavel = true;
            acao = false;
            tfid.setEnabled(true);

            tfcpf.setEnabled(true);
            tfnome.setEnabled(true);
            tflogin.setEnabled(true);
            tfsenha.setEnabled(true);
            tfendereco.setEnabled(true);
            tfdata.setEnabled(true);
            cbadmin.setEnabled(true);
            cbativo.setEnabled(true);

            btSalvar.setVisible(true);
            btCancelar.setVisible(true);
            btBuscar.setVisible(false);
            btRemover.setVisible(false);
            btInserir.setVisible(false);
            btimagem.setVisible(true);
            btAtualizar.setVisible(false);
        });

        btimagem.addActionListener((ActionEvent e) -> {
            if (imgVariavel) {
                imgVariavel = false;
                FileFilter imageFilter = new FileNameExtensionFilter("Image files", ImageIO.getReaderFileSuffixes());
                JFileChooser fc = new JFileChooser();
                fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                fc.setFileFilter(imageFilter);
                if (fc.showOpenDialog(cp) == JFileChooser.APPROVE_OPTION) {
                    File img = fc.getSelectedFile();
                    origem = fc.getSelectedFile().getAbsolutePath();
                    try {
                        ImageIcon icone = new javax.swing.ImageIcon(img.getAbsolutePath());
                        Image imagemAux1;
                        imagemAux1 = icone.getImage();
                        icone.setImage(imagemAux1.getScaledInstance(300, 300, Image.SCALE_FAST));
                        lbimagem2.setIcon(icone);
                    } catch (Exception ex) {
                        System.out.println("Erro: " + ex.getMessage());
                    }
                }
            }
        });
        btRemover.addActionListener((ActionEvent e) -> {
            if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
                    "Confirma a exclusão do registro?", "Confirm",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {

                controle.remover(cliente);
                lbAviso.setText("Removeu");

                tfcpf.setText("");
                tfnome.setText("");
                tflogin.setText("");
                tfsenha.setText("");
                tfendereco.setText("");
                tfdata.setText("");
                cbadmin.setSelected(false);
                cbativo.setSelected(false);

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btRemover.setVisible(false);
                btInserir.setVisible(false);
                btimagem.setVisible(false);
                btAtualizar.setVisible(true);

                tfid.setEnabled(true);
                tfid.requestFocus();
                tfid.setText("");

            } else {
                lbAviso.setText("Cancelada a remoção");
            }
        });
        btListar.addActionListener((ActionEvent e) -> {
            new GUIListagemCliente(controle.list());
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dados.clear();
                List<Cliente> listaCliente = controle.list();
                for (Cliente a : listaCliente) {
                    dados.add(a.toString());
                }

            }
        });
        setLocationRelativeTo(null);
        setModalityType(DEFAULT_MODALITY_TYPE);
        setVisible(true);
    }

    private boolean verificaEntrada(String verificar) {
        String a = "";

        a += tfid.getText();
        a += tfcpf.getText();
        a += tfnome.getText();
        a += tflogin.getText();
        a += tfsenha.getText();
        a += tfendereco.getText();
        a += tfdata.getText();
        a += cbadmin.isSelected();
        a += cbativo.isSelected();

        return a.contains(verificar);
    }
}
