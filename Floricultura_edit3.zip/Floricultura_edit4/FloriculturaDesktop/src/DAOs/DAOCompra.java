package DAOs;

import Entidades.Cliente;
import Entidades.Compra;
import java.util.ArrayList;
import java.util.List;

public class DAOCompra extends DAOGenerico<Compra> {

    public DAOCompra() {
        super(Compra.class);
    }

    public int autoIdCompra() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idCompra) FROM Compra e").getSingleResult();

        if (a != null) {

            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Compra> listById(int id) {
        return em.createQuery("SELECT e FROM Compra e WHERE e.idCompra = :id").setParameter("id", id).getResultList();
    }

    public List<Compra> listInOrderId() {
        return em.createQuery("SELECT e FROM Compra e ORDER BY e.idCompra").getResultList();
    }

    public List<Compra> listByClienteid(int clienteid) {
        return em.createQuery("SELECT e FROM Compra e WHERE e.clienteidCompra = :clienteid").setParameter("clienteid", clienteid).getResultList();
    }

    public List<Compra> listInOrderClienteid() {
        return em.createQuery("SELECT e FROM Compra e ORDER BY e.clienteidCompra").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Compra> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderClienteid();
        }
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            String batatinha = String.valueOf((lf.get(i).getClienteId()));
            int a = 29;
            int b = 30;
            while (!(batatinha.substring(b, b + 1).equals(" "))) {                                
                b++;
            }
            String idCliente = batatinha.substring(a,b+1);

        ls.add("ID da Compra: " + lf.get(i).getIdCompra() + " ID do Cliente - : " + idCliente + " - Data: " + lf.get(i).getData());
        }
        return ls;
    }
}
