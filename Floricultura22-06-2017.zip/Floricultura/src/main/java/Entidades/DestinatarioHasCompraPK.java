/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Hideky
 */
@Embeddable
public class DestinatarioHasCompraPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "destinatario_id")
    private int destinatarioId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "compra_idcompra")
    private int compraIdcompra;

    public DestinatarioHasCompraPK() {
    }

    public DestinatarioHasCompraPK(int destinatarioId, int compraIdcompra) {
        this.destinatarioId = destinatarioId;
        this.compraIdcompra = compraIdcompra;
    }

    public int getDestinatarioId() {
        return destinatarioId;
    }

    public void setDestinatarioId(int destinatarioId) {
        this.destinatarioId = destinatarioId;
    }

    public int getCompraIdcompra() {
        return compraIdcompra;
    }

    public void setCompraIdcompra(int compraIdcompra) {
        this.compraIdcompra = compraIdcompra;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) destinatarioId;
        hash += (int) compraIdcompra;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DestinatarioHasCompraPK)) {
            return false;
        }
        DestinatarioHasCompraPK other = (DestinatarioHasCompraPK) object;
        if (this.destinatarioId != other.destinatarioId) {
            return false;
        }
        if (this.compraIdcompra != other.compraIdcompra) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entidades.DestinatarioHasCompraPK[ destinatarioId=" + destinatarioId + ", compraIdcompra=" + compraIdcompra + " ]";
    }
    
}
