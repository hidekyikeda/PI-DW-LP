/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1.controller;

import DAOs.DAOCliente;
import Entidades.Cliente;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hideky
 */
@WebServlet(name = "Registro", urlPatterns = {"/Registro"})
public class Registro extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            DAOCliente controle = new DAOCliente();
            Cliente cliente = new Cliente();

            RequestDispatcher rd = request.getRequestDispatcher("sucesso.jsp");
            RequestDispatcher error = request.getRequestDispatcher("erroDados.jsp");

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date hoje = new Date();
            Date Data = new Date();
            String CPF = request.getParameter("CPF");
            String Nome = request.getParameter("Nome");
            String Login = request.getParameter("Login");
            String Senha = request.getParameter("Senha");
            String Endereco = request.getParameter("Endereco");
            boolean admin = false;
            boolean ativo = true;

            try {
                sdf.setLenient(false);
                String dataProvisoria = request.getParameter("Data");
                if ((sdf.parse(dataProvisoria)).after(hoje)) {
                    int erro = 23523 / 0;
                }

                Data = sdf.parse(dataProvisoria);
                out.println("Data Provisória: " + dataProvisoria + "////// Data: " + Data);
            } catch (Exception ex) {
                error.forward(request, response);
                out.println("CAIU NESSE CARAIO DE CATCH");
            }

            int idCliente = 0;
            double Divida = 0;
            boolean condicao = false;

            String proibidos = "[+&amp;@#$/%?'\"=~_()|!:,.;]";
            List<String> lista_cliente = controle.listStrings();

            out.println("Vai entrar no for");

            for (int i = 0; i < lista_cliente.size() - 1; i++) {

                Cliente cliente_existente = controle.obter(Integer.valueOf(lista_cliente.get(i)));
                out.println("Ta no for");

//                if((cliente_existente.getIdCliente())>idCliente){
//                    idCliente = (cliente_existente.getIdCliente());
//                }
                if ((String.valueOf((cliente_existente.getLogin())).equals(String.valueOf(Login))) || (String.valueOf((cliente_existente.getCpf())).equals(String.valueOf(CPF)))) {
                    out.println("Ta no for1 if");
                    condicao = true;
                }
                if ((String.valueOf((cliente_existente.getLogin())).contains(proibidos)) || ((String.valueOf(cliente_existente.getSenha()).contains(proibidos)))) {
                    out.println("Ta no for 2if");
                    condicao = true;
                }

            }

            idCliente++;

            List<Cliente> dados;

            if (condicao) {

                error.forward(request, response);
                condicao = false;
                out.println("Ta no 1f");

            } else {

                dados = savePrint(idCliente, CPF, Nome, Login, Senha, Endereco, Divida, Data, admin, ativo);

                rd.forward(request, response);

            }

            // HttpSession sessao = request.getSession();
        }
    }

    private List<Cliente> savePrint(Integer idCliente, String CPF, String Nome, String Login, String Senha, String Endereco, double Divida, Date Data, boolean admin, boolean ativo) {
        DAOCliente controle = new DAOCliente();
        Cliente cliente = new Cliente();
        System.out.println("Passou 1");

        cliente.setIdCliente(controle.autoIdCliente());
        cliente.setCpf(CPF);
        cliente.setNome(Nome);
        cliente.setLogin(Login);
        cliente.setSenha(Senha);
        cliente.setEndereco(Endereco);
        cliente.setDivida(Divida);
        cliente.setDatanascimento(Data);
        cliente.setAdmin(admin);
        cliente.setAtivo(ativo);

        System.out.println("Passou 2");

        controle.inserir(cliente);

        System.out.println("Inseriu");

        List<Cliente> dado = new ArrayList<>();
        dado = controle.listById(idCliente);
        System.out.println(dado);
        System.out.println("Listou");
        return dado;
    }

    private List<Cliente> list() {
        List<Cliente> list = new ArrayList<>();
        DAOCliente controle = new DAOCliente();
        list = controle.listInOrderCpf();
        return list;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
