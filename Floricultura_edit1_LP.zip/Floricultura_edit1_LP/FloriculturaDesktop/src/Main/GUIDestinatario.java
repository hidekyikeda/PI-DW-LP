package Main;

import DAOs.DAODestinatario;
import Entidades.Destinatario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.ImageIcon;

/**
 *
 * @author Dotor André, Dotor Gabriel, Dotor Hideky, Dotor Sergio
 */
public class GUIDestinatario extends JFrame {

    private Container cp;
    private JPanel pNorte = new JPanel(new FlowLayout());
    private JPanel pCentro = new JPanel(new GridLayout(2, 2));
    private JPanel pSul = new JPanel(new FlowLayout());
    private JButton btBuscar = new JButton("Buscar");
    private JButton btInserir = new JButton("Inserir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btRemover = new JButton("Remover");
    private JButton btAtualizar = new JButton("Atualizar");
    private JButton btListar = new JButton("Listar");

    Image x;
    ImageIcon ifind = new ImageIcon(getClass().getResource("/icons/find.png"));
    ImageIcon icreate = new ImageIcon(getClass().getResource("/icons/create.png"));
    ImageIcon icancel = new ImageIcon(getClass().getResource("/icons/cancelar.png"));
    ImageIcon iupdate = new ImageIcon(getClass().getResource("/icons/update.png"));
    ImageIcon isave = new ImageIcon(getClass().getResource("/icons/save.png"));
    ImageIcon iremove = new ImageIcon(getClass().getResource("/icons/delete.png"));
    private JTextField tfid = new JTextField(20);
    private JTextField tfendereco = new JTextField(20);

    private JLabel lbid = new JLabel("id");
    private JLabel lbendereco = new JLabel("endereco");

    private JLabel lbAviso = new JLabel("Aviso");
    DAODestinatario controle = new DAODestinatario();
    Destinatario destinatario = new Destinatario();
    boolean acao;

    ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
    List<String> dados = new ArrayList<>();

    String[] colunas = {"id", "endereco"};

    public GUIDestinatario() {

        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("Cadastro de Destinatario");

        pNorte.add(lbid);
        pNorte.add(tfid);
        pNorte.add(btBuscar);
        pNorte.add(btInserir);
        pNorte.add(btSalvar);
        pNorte.add(btCancelar);
        pNorte.add(btRemover);
        pNorte.add(btAtualizar);
        pNorte.add(btListar);

        Image x;

        x = ifind.getImage();
        ifind.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btBuscar.setIcon(ifind);

        x = icreate.getImage();
        icreate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btInserir.setIcon(icreate);

        x = isave.getImage();
        isave.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btSalvar.setIcon(isave);

        x = icancel.getImage();
        icancel.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btCancelar.setIcon(icancel);

        x = iremove.getImage();
        iremove.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btRemover.setIcon(iremove);

        x = iupdate.getImage();
        iupdate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btAtualizar.setIcon(iupdate);

        btInserir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);
        btRemover.setVisible(false);
        btAtualizar.setVisible(false);

        pCentro.add(lbendereco);
        pCentro.add(tfendereco);
        tfendereco.setEnabled(false);

        pSul.add(lbAviso);
        cp.add(pNorte, BorderLayout.NORTH);
        cp.add(pCentro, BorderLayout.CENTER);
        cp.add(pSul, BorderLayout.SOUTH);

        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.valueOf(tfid.getText());
                    //Seu código de validação da chave vai aqui
                    destinatario = controle.obter(id);
                    lbAviso.setBackground(Color.green);

                    if (destinatario != null) { //se encontrou

                        tfid.setText(String.valueOf(destinatario.getId()));

                        tfendereco.setText(String.valueOf(destinatario.getEndereco()));

                        btAtualizar.setVisible(true);
                        btRemover.setVisible(true);
                        lbAviso.setBackground(Color.green);
                        lbAviso.setText("Achou na lista");

                    } else {

                        lbAviso.setText("Não achou na lista");
                        lbAviso.setBackground(Color.red);
                        btInserir.setVisible(true);
                        btAtualizar.setVisible(false);
                        btRemover.setVisible(false);
                    }

                } catch (Exception err) {
                    lbAviso.setText("Erro nos dados");
                    lbAviso.setBackground(Color.red);
                }

            }
        }
        );
        btInserir.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = true;
                btBuscar.setVisible(false);
                tfendereco.setEnabled(true);
                tfid.setEnabled(false);

                btInserir.setVisible(false);
                btRemover.setVisible(false);
                btAtualizar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
            }
        }
        );
        btSalvar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    Destinatario destinatarioNovo = new Destinatario(Integer.valueOf(tfid.getText()), String.valueOf(tfendereco.getText()));

                    if (acao) {

                        controle.inserir(destinatarioNovo);
                        lbAviso.setText("Registro inserido");

                    } else {
                        controle.atualizar(destinatarioNovo);
                        lbAviso.setText("Registro alterado");

                    }

                    tfendereco.setEnabled(false);
                    tfendereco.setText("");
                    tfid.setEnabled(true);

                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                } catch (Exception ex) {
                    lbAviso.setText("Erro nos dados");
                }
            }
        }
        );
        btCancelar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                lbAviso.setText("Cancelado");
                tfid.setEnabled(true);
                tfid.requestFocus();
                tfid.selectAll();

                tfendereco.setEnabled(false);
                tfendereco.setText("");

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
            }
        }
        );
        btAtualizar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                acao = false;
                tfid.setEnabled(true);

                tfendereco.setEnabled(true);

                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btRemover.setVisible(false);
                btAtualizar.setVisible(false);

            }
        }
        );
        btRemover.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
                        "Confirma a exclusão do registro?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {

                    controle.remover(destinatario);
                    lbAviso.setText("Removeu");

                    tfendereco.setText("");
                    btRemover.setVisible(false);
                    btAtualizar.setVisible(false);
                    tfid.setEnabled(true);
                    tfid.requestFocus();
                    tfid.setText("");

                } else {
                    lbAviso.setText("Cancelada a remoção");
                }

            }
        }
        );
        btListar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                new GUIListagem(controle.list());
            }
        
                });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dados.clear();
                List<Destinatario> listaDestinatario = controle.list();
                for (Destinatario a : listaDestinatario) {
                    dados.add(a.toString());
                }
                manipulaArquivo.salvarArquivo("src/permanencia.txt", dados);

                System.exit(0);
            }
        });
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private boolean verificaEntrada(String verificar) {
        String a = "";

        a += tfid.getText();
        a += tfendereco.getText();

        return a.contains(verificar);
    }
}
