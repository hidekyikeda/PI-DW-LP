package Main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;


public class GUIMenuPrincipal extends JFrame {

    Container cp;
    JPanel pnNorte = new JPanel();
    JPanel pnCentro = new JPanel();
    JLabel lbTitulo = new JLabel("Floricultura do Hideky");



    JLabel labelComImagemDeTamanhoDiferente = new JLabel();

    JMenuBar menuBar = new JMenuBar();
    JMenu menuFloricultura = new JMenu("Floricultura");
    JMenuItem cadCompra = new JMenuItem("Compra");
    JMenuItem cadCliente = new JMenuItem("Cliente");
    JMenuItem cadDestinatario = new JMenuItem("Destinatario");
    JMenuItem cadFlor = new JMenuItem("Flor");
    
    JMenu menuCompor = new JMenu("Composições");


    JMenuItem cadDestinatarioHasCompra = new JMenuItem("Destinatario has compra");
    JMenuItem cadFlorHasCompra = new JMenuItem("Flor has compra");

    JMenu menuScreen = new JMenu("Posicionamento no monitor");
    JMenuItem posicaoNaJanela = new JMenuItem("Onde está...");

    public GUIMenuPrincipal() {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(800,600);
        setTitle("Menu Floricultura do Hideky");

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        pnNorte.add(lbTitulo);

        pnNorte.setBackground(Color.LIGHT_GRAY);

        //para ajustar o tamanho de uma imagem
        try {
            ImageIcon icone = new ImageIcon(getClass().getResource("/icons/logo.png"));
            Image imagemAux;
            imagemAux = icone.getImage();
            icone.setImage(imagemAux.getScaledInstance(500, 500, Image.SCALE_FAST));

            labelComImagemDeTamanhoDiferente = new JLabel();
            labelComImagemDeTamanhoDiferente.setIcon(icone);
        } catch (Exception e) {
            System.out.println("erro ao carregar a imagem");
        }

        pnCentro.add(labelComImagemDeTamanhoDiferente);
        pnCentro.setBackground(Color.BLACK);

        cp.add(pnNorte, BorderLayout.NORTH);
        cp.add(pnCentro, BorderLayout.CENTER);

        setJMenuBar(menuBar);
        menuBar.add(menuFloricultura);

        menuFloricultura.add(cadCliente);
        menuFloricultura.add(cadFlor);
        menuFloricultura.add(cadCompra);
        menuFloricultura.add(cadDestinatario);

        menuBar.add(menuCompor);

 
        menuCompor.add(cadFlorHasCompra);
        menuCompor.add(cadDestinatarioHasCompra);

        menuScreen.setVisible(false); //mostrar se precisar ajustar a posicao na tela
        menuBar.add(menuScreen);


        cadCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUICliente gcliente = new GUICliente();
            }
        });
        cadCompra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUICompra gcompra = new GUICompra();
            }
        });
        cadDestinatario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIDestinatario gdestinatario = new GUIDestinatario(p);
            }
        });
        cadFlor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIFlor gflor = new GUIFlor();
            }
        });


        cadFlorHasCompra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new GUIFlorHasCompra();
            }
        });
        cadFlorHasCompra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new GUIFlorHasCompra();
            }
        });

        posicaoNaJanela.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("X " + getBounds().x);
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Sai do sistema  
                System.exit(0);
            }
        });

        
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
