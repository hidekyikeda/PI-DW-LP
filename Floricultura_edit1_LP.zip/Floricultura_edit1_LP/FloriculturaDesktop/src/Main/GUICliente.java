package Main;

import DAOs.DAOCliente;
import Entidades.Cliente;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;

/**
 *
 * @author Dotor André, Dotor Gabriel, Dotor Hideky, Dotor Sergio
 */
public class GUICliente extends JFrame {

    private Container cp;
    private JPanel pNorte = new JPanel(new FlowLayout());
    private JPanel pCentro = new JPanel(new GridLayout(9, 2));
    private JPanel pSul = new JPanel(new FlowLayout());
    private JButton btBuscar = new JButton("Buscar");
    private JButton btInserir = new JButton("Inserir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btRemover = new JButton("Remover");
    private JButton btAtualizar = new JButton("Atualizar");
    private JButton btListar = new JButton("Listar");

    private SimpleDateFormat sdf_data = new SimpleDateFormat("dd/MM/yyyy");

    Image x;
    ImageIcon ifind = new ImageIcon(getClass().getResource("/icons/find.png"));
    ImageIcon icreate = new ImageIcon(getClass().getResource("/icons/create.png"));
    ImageIcon icancel = new ImageIcon(getClass().getResource("/icons/cancelar.png"));
    ImageIcon iupdate = new ImageIcon(getClass().getResource("/icons/update.png"));
    ImageIcon isave = new ImageIcon(getClass().getResource("/icons/save.png"));
    ImageIcon iremove = new ImageIcon(getClass().getResource("/icons/delete.png"));
    private JTextField tfid = new JTextField(20);
    private JTextField tfcpf = new JTextField(20);
    private JTextField tfnome = new JTextField(20);
    private JTextField tflogin = new JTextField(20);
    private JTextField tfsenha = new JTextField(20);
    private JTextField tfendereco = new JTextField(20);
    private JTextField tfdata = new JTextField(20);
    private JCheckBox cbadmin = new JCheckBox("sim/não");
    private JCheckBox cbativo = new JCheckBox("sim/não");

    private JLabel lbid = new JLabel("id");
    private JLabel lbcpf = new JLabel("cpf");
    private JLabel lbnome = new JLabel("nome");
    private JLabel lblogin = new JLabel("login");
    private JLabel lbsenha = new JLabel("senha");
    private JLabel lbendereco = new JLabel("endereco");
    private JLabel lbdata = new JLabel("data");
    private JLabel lbadmin = new JLabel("admin");
    private JLabel lbativo = new JLabel("ativo");

    private JLabel lbAviso = new JLabel("Aviso");
    DAOCliente controle = new DAOCliente();
    Cliente cliente = new Cliente();
    boolean acao;

    ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
    List<String> dados = new ArrayList<>();

    String[] colunas = {"id", "cpf", "nome", "login", "senha", "endereco", "data", "admin", "ativo"};

    public GUICliente() {

        sdf_data.setLenient(false);
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        setTitle("Cadastro de Cliente");

        pNorte.add(lbid);
        pNorte.add(tfid);
        pNorte.add(btBuscar);
        pNorte.add(btInserir);
        pNorte.add(btSalvar);
        pNorte.add(btCancelar);
        pNorte.add(btRemover);
        pNorte.add(btAtualizar);
        pNorte.add(btListar);

        Image x;

        x = ifind.getImage();
        ifind.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btBuscar.setIcon(ifind);

        x = icreate.getImage();
        icreate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btInserir.setIcon(icreate);

        x = isave.getImage();
        isave.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btSalvar.setIcon(isave);

        x = icancel.getImage();
        icancel.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btCancelar.setIcon(icancel);

        x = iremove.getImage();
        iremove.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btRemover.setIcon(iremove);

        x = iupdate.getImage();
        iupdate.setImage(x.getScaledInstance(20, 20, Image.SCALE_FAST));
        btAtualizar.setIcon(iupdate);

        btInserir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);
        btRemover.setVisible(false);
        btAtualizar.setVisible(false);

        cbadmin.setEnabled(false);
        cbativo.setEnabled(false);

        pCentro.add(lbcpf);
        pCentro.add(tfcpf);
        tfcpf.setEnabled(false);

        pCentro.add(lbnome);
        pCentro.add(tfnome);
        tfnome.setEnabled(false);

        pCentro.add(lblogin);
        pCentro.add(tflogin);
        tflogin.setEnabled(false);

        pCentro.add(lbsenha);
        pCentro.add(tfsenha);
        tfsenha.setEnabled(false);

        pCentro.add(lbendereco);
        pCentro.add(tfendereco);
        tfendereco.setEnabled(false);

        pCentro.add(lbdata);
        pCentro.add(tfdata);
        tfdata.setEnabled(false);

        pCentro.add(lbadmin);
        pCentro.add(cbadmin);

        pCentro.add(lbativo);
        pCentro.add(cbativo);

        pSul.add(lbAviso);
        cp.add(pNorte, BorderLayout.NORTH);
        cp.add(pCentro, BorderLayout.CENTER);
        cp.add(pSul, BorderLayout.SOUTH);

        btBuscar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.valueOf(tfid.getText());
                    //Seu código de validação da chave vai aqui
                    cliente = controle.obter(id);
                    lbAviso.setBackground(Color.green);

                    if (cliente != null) { //se encontrou

                        tfid.setText(String.valueOf(cliente.getId()));

                        tfcpf.setText(String.valueOf(cliente.getCpf()));

                        tfnome.setText(String.valueOf(cliente.getNome()));

                        tflogin.setText(String.valueOf(cliente.getLogin()));

                        tfsenha.setText(String.valueOf(cliente.getSenha()));

                        tfendereco.setText(String.valueOf(cliente.getEndereco()));

                        tfdata.setText(sdf_data.format(cliente.getDatanascimento()));

                        cbadmin.setSelected(cliente.getAdmin());

                        cbativo.setSelected(cliente.getAtivo());

                        btAtualizar.setVisible(true);
                        btRemover.setVisible(true);
                        lbAviso.setBackground(Color.green);
                        lbAviso.setText("Achou na lista");

                    } else {

                        cbadmin.setSelected(false);
                        cbativo.setSelected(false);
                        lbAviso.setText("Não achou na lista");
                        lbAviso.setBackground(Color.red);
                        btInserir.setVisible(true);
                        btAtualizar.setVisible(false);
                        btRemover.setVisible(false);
                    }

                } catch (Exception err) {
                    lbAviso.setText("Erro nos dados");
                    lbAviso.setBackground(Color.red);
                }

            }
        }
        );
        btInserir.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = true;
                btBuscar.setVisible(false);
                tfcpf.setEnabled(true);
                tfnome.setEnabled(true);
                tflogin.setEnabled(true);
                tfsenha.setEnabled(true);
                tfendereco.setEnabled(true);
                tfdata.setEnabled(true);
                cbadmin.setEnabled(true);
                cbativo.setEnabled(true);
                tfid.setEnabled(false);

                btInserir.setVisible(false);
                btRemover.setVisible(false);
                btAtualizar.setVisible(false);
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
            }
        }
        );
        btSalvar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    String data = tfdata.getText();//mudar esse txt field do caraio aqui

                    if (!data.matches("^[0-9/]+$")) {
                        int erro = 69 / 0;
                    }
                    if (tfid.getText().equals("") || verificaEntrada(";")) {
                        int erro = 1 / 0;
                    }

                    Cliente clienteNovo = new Cliente(Integer.valueOf(tfid.getText()), String.valueOf(tfcpf.getText()), String.valueOf(tfnome.getText()), String.valueOf(tflogin.getText()), String.valueOf(tfsenha.getText()), String.valueOf(tfendereco.getText()), sdf_data.parse(tfdata.getText()), cbadmin.isSelected(), cbativo.isSelected());

                    if (acao) {

                        controle.inserir(clienteNovo);
                        lbAviso.setText("Registro inserido");

                    } else {
                        controle.atualizar(clienteNovo);
                        lbAviso.setText("Registro alterado");

                    }

                    tfcpf.setEnabled(false);
                    tfcpf.setText("");
                    tfnome.setEnabled(false);
                    tfnome.setText("");
                    tflogin.setEnabled(false);
                    tflogin.setText("");
                    tfsenha.setEnabled(false);
                    tfsenha.setText("");
                    tfendereco.setEnabled(false);
                    tfendereco.setText("");
                    tfdata.setEnabled(false);
                    tfdata.setText("");
                    cbadmin.setEnabled(false);
                    cbadmin.setSelected(false);
                    cbativo.setEnabled(false);
                    cbativo.setSelected(false);
                    tfid.setEnabled(true);

                    btSalvar.setVisible(false);
                    btCancelar.setVisible(false);
                    btBuscar.setVisible(true);
                } catch (Exception ex) {
                    lbAviso.setText("Erro nos dados");
                }
            }
        }
        );
        btCancelar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                lbAviso.setText("Cancelado");
                tfid.setEnabled(true);
                tfid.requestFocus();
                tfid.selectAll();

                tfcpf.setEnabled(false);
                tfcpf.setText("");
                tfnome.setEnabled(false);
                tfnome.setText("");
                tflogin.setEnabled(false);
                tflogin.setText("");
                tfsenha.setEnabled(false);
                tfsenha.setText("");
                tfendereco.setEnabled(false);
                tfendereco.setText("");
                tfdata.setEnabled(false);
                tfdata.setText("");
                cbadmin.setEnabled(false);
                cbadmin.setSelected(false);
                cbativo.setEnabled(false);
                cbativo.setSelected(false);

                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
            }
        }
        );
        btAtualizar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                acao = false;
                tfid.setEnabled(true);

                tfcpf.setEnabled(true);
                tfnome.setEnabled(true);
                tflogin.setEnabled(true);
                tfsenha.setEnabled(true);
                tfendereco.setEnabled(true);
                tfdata.setEnabled(true);
                cbadmin.setEnabled(true);
                cbativo.setEnabled(true);

                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btRemover.setVisible(false);
                btAtualizar.setVisible(false);

            }
        }
        );
        btRemover.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null,
                        "Confirma a exclusão do registro?", "Confirm",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {

                    controle.remover(cliente);
                    lbAviso.setText("Removeu");

                    tfcpf.setText("");
                    tfnome.setText("");
                    tflogin.setText("");
                    tfsenha.setText("");
                    tfendereco.setText("");
                    tfdata.setText("");
                    cbadmin.setSelected(false);
                    cbativo.setSelected(false);
                    btRemover.setVisible(false);
                    btAtualizar.setVisible(false);
                    tfid.setEnabled(true);
                    tfid.requestFocus();
                    tfid.setText("");

                } else {
                    lbAviso.setText("Cancelada a remoção");
                }

            }
        }
        );
        btListar.addActionListener(
                new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                new GUIListagem(controle.list());
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dados.clear();
                List<Cliente> listaCliente = controle.list();
                for (Cliente a : listaCliente) {
                    dados.add(a.toString());
                }
                manipulaArquivo.salvarArquivo("src/permanencia.txt", dados);

                System.exit(0);
            }
        });
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private boolean verificaEntrada(String verificar) {
        String a = "";

        a += tfid.getText();
        a += tfcpf.getText();
        a += tfnome.getText();
        a += tflogin.getText();
        a += tfsenha.getText();
        a += tfendereco.getText();
        a += tfdata.getText();
        a += cbadmin.isSelected();
        a += cbativo.isSelected();

        return a.contains(verificar);
    }
}
