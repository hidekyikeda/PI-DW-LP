function validacaoRegistro(){
if (document.form.cpf.value == ""){
alert("Campo \"CPF\" obrigatório.");
        document.form.cpf.focus();
        return false;
}
if (document.form.nome.value == ""){
alert("Campo \"Nome\" obrigatório.");
        document.form.nome.focus();
        return false;
}
if (document.form.login.value == ""){
alert("Campo \"Login\" obrigatório.");
        document.form.login.focus();
        return false;
}
if (document.form.senha.value == ""){
alert("Campo \"Senha\" obrigatório.");
        document.form.senha.focus();
        return false;
}if (document.form.senha.value.length < 4){
alert("A senha deve conter no mínimo 4 caracteres.");
        document.form.senha.focus();
        return false
}
if (document.form.endereco.value == ""){
alert("Campo \"Endereço\" obrigatório.");
        document.form.endereco.focus();
        return false;
}
if (document.form.endereco.value.indexOf('Rua') == - 1 && document.form.endereco.value.indexOf('Avenida') == - 1 && document.form.endereco.value.indexOf('rua') == - 1 && document.form.endereco.value.indexOf('avenida') == - 1){
alert("Indique no campo endereço se é uma \"Rua\" ou \"Avenida\"");
        document.form.endereco.focus();
        return false;
}
if (document.form.data.value == ""){
alert("Campo \"data\" obrigatório.");
        document.form.data.focus();
        return false;
}

	
        }
//function validacaoLogin(){
//    if (document.formlogin.login.value == ""){
//        alert("Campo \"Login\" não foi preenchido.");
//        document.formlogin.login.focus();
//        return false;
//    }
//    if (document.formlogin.senha.value == ""){
//        alert("Campo \"Senha\" não foi preenchido.");
//        document.formlogin.senha.focus();
//        return false;
//    }
